(
  (1 "a" 0.5)
  (2 missing 1.5)
  (3 "c" missing)
)
