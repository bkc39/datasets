(
  ("Food and Tobacco" 22.2 44.5 59.6 73.2 86.8)
  ("Household Operation" 10.5 15.5 29 36.5 46.2)
  ("Medical and Health" 3.53 5.76 9.71 14 21.1)
  ("Personal Care" 1.04 1.98 2.45 3.4 5.4)
  ("Private Education" 0.341 0.974 1.8 2.6 3.64)
)
